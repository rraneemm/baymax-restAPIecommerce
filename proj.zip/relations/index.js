const {User} =require('../models/User')
const {Cart} =require('../models/Cart')
const {Order} =require('../models/Order')
const {OrderItem} =require('../models/OrderItem')
const {CartItem} =require('../models/CartItem')
const { Product } = require('../models/Product')

const relations =()=> {

    // user to cart 
    User.hasOne(Cart)
    Cart.belongsTo(User)

    //product to cart 
    Cart.belongsToMany(Product,{through:CartItem})
    Product.belongsToMany(Cart,{through:CartItem})

    //user to order
    User.hasMany(Order)
    Order.belongsTo(User)

    //order to products
    Order.belongsToMany(Product,{through:OrderItem})
    Product.belongsToMany(Order,{through:OrderItem})



}

module.exports ={relations}