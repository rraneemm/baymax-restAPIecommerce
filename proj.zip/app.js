const  express = require('express');

const bodyParser = require('body-parser');
const { appendFile } = require('fs');

const routes = require('../proj/routes/site');
const app = express();

const {sequelize} = require('./db/database');
const {relations} =require('./relations')
relations()
// database.execute('SELECT * FROM trialingfinal.products')
// .then(result =>{
//     console.log(result);
// }) 
// .catch(err=>{
//     console.log(err);
// })

app.use(bodyParser.json());

app.use('/shop', routes);

sequelize.sync(
    // {force:true}
).then(()=>{

    app.listen(8080);
})

