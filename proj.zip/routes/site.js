const express = require('express');

const author = require('../author/site');

const router = express.Router();
//user
router.get('/login',author.logIn);
router.get('/signup',author.signUp);
//product
router.post('/add-product',author.addProduct);
router.get('/search-product/:id',author.findById);
router.get('/',author.getAll);
router.delete('/:id',author.deleteProduct);
//order
router.post('/order/:userId',author.createOrder);

module.exports = router; 
