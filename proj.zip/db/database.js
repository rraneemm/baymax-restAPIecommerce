// const mysql = require('mysql2');

// const pool = mysql.createPool({
//     host: 'localhost',
//     user: 'root',
//     database: 'trialingfinal',
//     password: 'Blueivy22mysql!'
// });

// module.exports = pool.promise();


const Sequelize = require('sequelize');
const path = require('path')

const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: path.join(__dirname, `ecommerce.sqlite`)
})

// export default Database
module.exports = {sequelize}