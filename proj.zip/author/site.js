const { countReset } = require("console");
//product
const {Product} = require('../models/Product')
const {
    addProduct,
    findById,
    getAll,
    deleteProduct
} = require('./services/Product.Service')

//order
const {Order} = require ('../models/Order')
const {
    createOrder
} =require('./services/Order.Service')

//user
const {User} = require ('../models/User')
const {
    signUp,
    logIn
} = require ('../author/services/User.service')

//User
exports.logIn = async (req, res) =>{
    const {userName, password}  = req.body
    const result = await logIn({userName,password})
    res.send(result)    
};

exports.signUp =async (req, res)=>{
    const user = req.body;
    const result = await signUp(user)
    console.log("after OP")
    res.send(result)
};
//Product
exports.addProduct =async(req,res,next)=>{
    const product = req.body;
    const result = await addProduct(product)
    res.send(result)
};

exports.findById =async(req,res)=>{
    console.log("find by id arrived")
    const {id} = req.params;
    const result = await findById(id)
    res.send(result)
};

exports.getAll =async(req,res)=>{
    const result = await getAll()
    res.send(result)
};

exports.deleteProduct= async (req,res)=>{
    const {id} = req.params;
    const result = await deleteProduct(id);
    res.send(result)
}

//Order
exports.createOrder =async (req,res) => {
    const {userId}= req.params
    const {order,products} = req.body
    const result = await createOrder({userId,order,products})
    res.send(result)
    
}
