const {Order} = require('../../models/Order')
const {User} = require('../../models/User')
const {Product} = require('../../models/Product');
const { OrderItem } = require('../../models/OrderItem');

/**
 * 
 * get user orders
 * add order => append products
 */


const createOrder =async(payload) => {
    //getting data 
    const user = await User.findByPk(payload.userId)
    // create order
    const order= await user.createOrder(payload.order)
    // adding products into the order
      await payload.products.forEach((prod)=> {
           order.addProduct(prod.id,{through:OrderItem})         

    })
    return order
}

module.exports = {createOrder}