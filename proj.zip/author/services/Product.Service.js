const {Product} =require('../../models/Product')
// import {Product} from '../../models/Product'
/* 
add product ✔✔
get all products ✔
delete product  destroy() ✔
find by id ✔✔
*/

exports.addProduct = async(payload) => {
    const product = await Product.create(payload)
    const message = 'Data is not valid'
    return product?  product : message
}

exports.findById = async(id) => {
    const product =await Product.findByPk(id)
    const message = 'Product is not found.'
    return product?  product : message
}

exports.getAll = async() => {
    return Product.findAll()
}

exports.deleteProduct = async (id) => {

    const product = await Product.findByPk(id)
    return product.destroy()

}
