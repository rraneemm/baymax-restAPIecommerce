const {User} = require ('../../models/User')

/*
log in --> search in database 
sign up --> add to the database
add product to cart 
*/

const signUp= async(payload)=>{
    const user = await User.create(payload)
    const message = 'Signed Up Successfully'
    return message
}

const logIn = async (payload)=>{
    const user = await User.findOne({where:{userName:payload.userName,password:payload.password}})
    if(user) {
        return user
    }
    const check = await User.findOne({where:{userName:payload.userName}})
    return !check? 'User not found ': 'Wrong username or password!'
}
module.exports = {
    signUp,
    logIn
}