const {sequelize} = require('../db/database');
const {Sequelize,Model} =require('sequelize')


class CartItem extends Model {}

CartItem.init({
    // id: {
    //     type: Sequelize.INTEGER,
    //     primaryKey:true,
    //     autoIncrement:true
    // },
},
{
    sequelize,
    modelName: 'cartItem',
    timestamps:false
}
);
CartItem.build();
module.exports= {CartItem}
