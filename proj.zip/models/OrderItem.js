const {sequelize} = require('../db/database');
const {Sequelize,Model} =require('sequelize')


class OrderItem extends Model {}

OrderItem.init({
    // id: {
    //     type: Sequelize.INTEGER,
    //     primaryKey:true,
    //     autoIncrement:true
    // },
},
{
    sequelize,
    modelName: 'orderItem',
    timestamps:false
}
);
OrderItem.build();
module.exports= {OrderItem}
