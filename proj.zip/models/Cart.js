const {sequelize} = require('../db/database');
const {Sequelize,Model} =require('sequelize')


class Cart extends Model {}

Cart.init({
    id: {
        type: Sequelize.INTEGER,
        primaryKey:true,
        autoIncrement:true
    },
    
    
},
{
    sequelize,
    modelName: 'cart'
}
);
Cart.build();
module.exports= {Cart}
