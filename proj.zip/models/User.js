const {sequelize} = require('../db/database');
const {Sequelize,Model} =require('sequelize')


class User extends Model {}

User.init({
    id: {
        type: Sequelize.INTEGER,
        primaryKey:true,
        autoIncrement:true
    },
    userName: {
        type: Sequelize.STRING,
        allowNull:false
    },
    email: {
        type: Sequelize.STRING,
        allowNull:false
    },
    password: {
        type: Sequelize.STRING,
        allowNull:false
    },
    
},
{
    sequelize,
    modelName: 'userInfo'
}
);
User.build();
module.exports= {User}
