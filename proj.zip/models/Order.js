const {sequelize} = require('../db/database');
const {Sequelize,Model,DataTypes} =require('sequelize')


class Order extends Model {}

Order.init({
    id: {
        type: Sequelize.INTEGER,
        primaryKey:true,
        autoIncrement:true
    },
    price: {
        type: Sequelize.DOUBLE,
        allowNull: false
    },
    status:{
        type: DataTypes.BOOLEAN,
        allowNull:false,
    },
    inquiry: {
        type: Sequelize.STRING,
        allowNull: true
    }
},
{
    sequelize,
    modelName: 'order'
}
);
Order.build();
module.exports= {Order}
