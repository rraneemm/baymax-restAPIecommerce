const {sequelize} = require('../db/database');
const {Sequelize,Model} =require('sequelize')


class Product extends Model {}

Product.init({
    id: {
        type: Sequelize.INTEGER,
        primaryKey:true,
        autoIncrement:true
    },
    name: {
        type: Sequelize.STRING,
        allowNull:false
    },
    desc: {
        type: Sequelize.STRING,
        allowNull: false,
    },
    img: {
        type: Sequelize.STRING,
        allowNull: true
    }
},
{
    sequelize,
    modelName: 'product'
}
);
Product.build();
module.exports= {Product}
